// js/product.js
import { apiGet, apiPost } from "./api.js";

export const productModule = {
  data: [],

  async load() {
    console.log("🔥 Loading products...");
    this.data = await apiGet("/api/products");
    console.log("Products loaded:", this.data);

    this.populateGlobalDatalist();   // <-- NEW
  },

  populateGlobalDatalist() {
    const dl = document.getElementById("productListGlobal");
    if (!dl) return;

    dl.innerHTML = "";
    this.data.forEach(p => {
      const opt = document.createElement("option");
      opt.value = p.name;  // keeps autocomplete clean
      opt.dataset.id = p.id;
      dl.appendChild(opt);
    });
  },

  findByName(name) {
    if (!name) return null;
    return this.data.find(p => p.name.toLowerCase() === name.trim().toLowerCase()) || null;
  },

  async create(product) {
    const res = await apiPost("/api/products", product);
    this.data.push(res);
    this.populateGlobalDatalist();
    return res;
  }
};
