// js/ui/ui.js
import { layout } from "./layout.js";
import { navigation } from "./navigation.js";

export const ui = {

  render() {
    // Insert layout into DOM
    document.getElementById("app").innerHTML = layout.renderShell();

    // Initialize navigation
    navigation.init();

    // Load default view
    navigation.loadView("invoiceCreate");
  }
};
